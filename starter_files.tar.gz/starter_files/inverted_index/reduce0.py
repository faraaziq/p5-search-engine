"""Reduce 0."""
